---
name: pytest-execution
description: Define pytest framework usage and execution rules for PatchSorter v2
license: MIT
compatibility: opencode
metadata:
  audience: maintainers
  workflow: github
---
# Pytest Execution Skill

This skill defines pytest framework usage and execution rules for PatchSorter v2.

## Purpose
Establishes the specific pytest execution standards that should be applied to code review process with clear performance and reliability guidelines.

## Rules and Standards
- Define test execution parameters and timeouts with appropriate defaults  
- Specify which tests should be run (all, changed files only) with clear logic for determining changes
- Set resource limits for test execution to prevent system overload
- Define success/failure criteria for test runs with comprehensive exit code handling
- Enforce consistent test structure and naming conventions across all test suites

## Integration Points
- Used by test-runner-agent for test execution  
- Connected to main-agent for result interpretation
- Provides framework rules to validation processes
- Integrated with coverage analysis for complete quality assessment

## Parameters
- `test_timeout_seconds` (integer): Maximum seconds allowed per test run with sensible defaults (30-60s)
- `max_test_workers` (integer): Maximum concurrent test workers based on available CPU cores
- `enable_coverage` (boolean): Whether to collect coverage data during testing 
- `fail_on_warnings` (boolean): Treat warnings as failures for more strict quality control
- `test_selection_mode` (string): How tests are selected ('all', 'changed_files', 'modified_only')
- `max_test_retries` (integer): Maximum number of retries for flaky tests

## Pytest Configuration Examples
```ini
# Standard pytest configuration with project-specific settings  
testpaths = ["tests"]
python_files = ["test_*.py"]
python_classes = ["Test*"] 
python_functions = ["test_*"]
addopts = "--verbose --tb=short -x"
timeout = 30
markers =
    slow: marks tests as slow
    integration: marks tests as integration tests

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
python_classes = ["Test*"] 
python_functions = ["test_*"]
addopts = "--verbose --tb=short -x"
timeout = 30
markers =
    slow: marks tests as slow
    integration: marks tests as integration tests
```

## Test Execution Guidelines
- Run all unit tests in CI environment for full regression coverage
- Execute only changed files during development to speed up local testing  
- Implement test retry logic for flaky tests that may fail due to external factors
- Use markers to categorize tests by type and execution time requirements
- Ensure proper cleanup of resources after each test run

## Performance Considerations
- Configure parallel execution based on available system resources 
- Set appropriate timeouts to prevent hanging tests from blocking the review process
- Implement selective test running to reduce CI pipeline times
- Use pytest fixtures efficiently to avoid redundant setup/teardown operations

## Script Integration
This skill's functionality is implemented by the script at `.opencode/skills/pytest-execution-skill/scripts/test_runner.py` which provides the actual execution logic for running pytest.