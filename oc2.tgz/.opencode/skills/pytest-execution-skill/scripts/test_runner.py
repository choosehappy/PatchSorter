#!/usr/bin/env python3
"""
Test runner script for PatchSorter v2 code review process.

This script executes pytest with specific project configurations and
returns structured results for the code review system.
"""

import subprocess
import json
import sys
from pathlib import Path
from typing import List, Dict, Any


def run_test_execution(
    test_paths: List[str], config: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Run pytest execution on specified test paths with project-specific configuration.

    Args:
        test_paths: List of test file/directory paths to execute
        config: Configuration dictionary for test execution settings

    Returns:
        Dictionary containing test results and statistics
    """

    # Default configuration if none provided
    if config is None:
        config = {
            "test_timeout_seconds": 30,
            "max_test_workers": 4,
            "enable_coverage": True,
            "fail_on_warnings": False,
        }

    try:
        # Prepare command - run pytest with JSON output format
        cmd = [
            sys.executable,
            "-m",
            "pytest",
            "--json-report",
            "--json-report-file=report.json",
            "--tb=short",
            "-v",
        ]

        # Add coverage if enabled
        if config.get("enable_coverage", True):
            cmd.extend(
                [
                    "--cov=src",
                    "--cov-report=term-missing",
                    "--cov-report=html:coverage_html_report",
                ]
            )

        # Add test paths to execute
        for path in test_paths:
            if Path(path).exists():
                cmd.append(str(path))

        # Run the tests with timeout
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=config.get("test_timeout_seconds", 30),
        )

        # Try to parse JSON report if it was generated
        test_report = {}
        try:
            with open("report.json", "r") as f:
                test_report = json.load(f)
        except Exception:
            pass  # No JSON report available

        # Parse standard output for summary statistics
        total_tests = 0
        passed_tests = 0
        failed_tests = 0
        error_tests = 0

        # Extract basic stats from pytest output
        stdout_lines = result.stdout.strip().split("\n") if result.stdout else []

        for line in stdout_lines:
            if "passed" in line and "failed" in line:
                # Example: "12 passed, 3 failed in 5.67s"
                parts = line.split()
                for i, part in enumerate(parts):
                    if part == "passed":
                        passed_tests = int(parts[i - 1])
                    elif part == "failed":
                        failed_tests = int(parts[i - 1])
                    elif part == "error" and i + 1 < len(parts):
                        error_tests = int(parts[i - 1])
                total_tests = passed_tests + failed_tests + error_tests
            elif line.startswith("===") or line.startswith("ERROR"):
                # Look for errors in output
                if "ERROR" in line:
                    error_tests += 1

        return {
            "success": True,
            "test_report": test_report,
            "summary": {
                "total_tests": total_tests,
                "passed_tests": passed_tests,
                "failed_tests": failed_tests,
                "error_tests": error_tests,
                "tests_executed": len(test_paths),
            },
            "errors": [],
            "stdout": result.stdout,
            "stderr": result.stderr,
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "test_report": {},
            "summary": {
                "total_tests": 0,
                "passed_tests": 0,
                "failed_tests": 0,
                "error_tests": 0,
                "tests_executed": len(test_paths),
            },
            "errors": [
                "Test execution timed out after {} seconds".format(
                    config.get("test_timeout_seconds", 30)
                )
            ],
            "stdout": "",
            "stderr": "",
        }
    except Exception as e:
        return {
            "success": False,
            "test_report": {},
            "summary": {
                "total_tests": 0,
                "passed_tests": 0,
                "failed_tests": 0,
                "error_tests": 0,
                "tests_executed": len(test_paths),
            },
            "errors": [f"Test execution failed: {str(e)}"],
            "stdout": "",
            "stderr": "",
        }


def main():
    """Main entry point for the test runner."""

    # Read input from stdin
    try:
        input_data = json.load(sys.stdin)
    except Exception as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "test_report": {},
                    "summary": {
                        "total_tests": 0,
                        "passed_tests": 0,
                        "failed_tests": 0,
                        "error_tests": 0,
                        "tests_executed": 0,
                    },
                    "errors": [f"Failed to read input: {str(e)}"],
                    "stdout": "",
                    "stderr": "",
                }
            )
        )
        sys.exit(1)

    # Extract test paths and config from input
    test_paths = input_data.get("test_paths", [])
    config = input_data.get("config", None)

    # Run the tests
    result = run_test_execution(test_paths, config)

    # Output results as JSON
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
