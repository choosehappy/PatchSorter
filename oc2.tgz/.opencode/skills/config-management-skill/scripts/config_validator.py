#!/usr/bin/env python3
"""
Configuration validator script for PatchSorter v2 code review process.

This script validates configuration files and parameters to ensure they meet
the project's requirements before being used in the code review process.
"""

import json
import sys
from pathlib import Path
from typing import Dict, Any, List


def validate_config(config: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate a configuration dictionary against defined rules.

    Args:
        config: Configuration dictionary to validate

    Returns:
        Dictionary with validation results and any errors found
    """
    # Default configuration values
    default_config = {
        "tool_settings": {
            "ruff": {"timeout_seconds": 30, "max_issues_per_file": 100},
            "mypy": {"timeout_seconds": 60, "strict_mode": True},
        },
        "analysis_scope": {
            "include_patterns": ["src/**/*.py"],
            "exclude_patterns": ["tests/**", "*/_test.py"],
        },
        "output_settings": {"format": "json", "verbose": False},
    }

    errors = []
    warnings = []

    # Validate tool settings
    if not isinstance(config.get("tool_settings"), dict):
        errors.append("tool_settings must be a dictionary")

    else:
        ruff_config = config["tool_settings"].get("ruff", {})
        mypy_config = config["tool_settings"].get("mypy", {})

        # Validate ruff settings
        if (
            not isinstance(ruff_config.get("timeout_seconds"), int)
            or ruff_config["timeout_seconds"] < 5
        ):
            errors.append("ruff.timeout_seconds must be an integer >= 5")

        if (
            not isinstance(ruff_config.get("max_issues_per_file"), int)
            or ruff_config["max_issues_per_file"] <= 0
        ):
            errors.append("ruff.max_issues_per_file must be a positive integer")

        # Validate mypy settings
        if (
            not isinstance(mypy_config.get("timeout_seconds"), int)
            or mypy_config["timeout_seconds"] < 10
        ):
            errors.append("mypy.timeout_seconds must be an integer >= 10")

        if not isinstance(mypy_config.get("strict_mode"), bool):
            errors.append("mypy.strict_mode must be a boolean")

    # Validate analysis scope
    if not isinstance(config.get("analysis_scope"), dict):
        errors.append("analysis_scope must be a dictionary")

    else:
        include_patterns = config["analysis_scope"].get("include_patterns", [])
        exclude_patterns = config["analysis_scope"].get("exclude_patterns", [])

        if not isinstance(include_patterns, list):
            errors.append("analysis_scope.include_patterns must be a list")

        if not isinstance(exclude_patterns, list):
            errors.append("analysis_scope.exclude_patterns must be a list")

    # Validate output settings
    if not isinstance(config.get("output_settings"), dict):
        errors.append("output_settings must be a dictionary")

    else:
        format_setting = config["output_settings"].get("format", "json")
        if format_setting not in ["json", "xml", "html"]:
            warnings.append(
                f"output_settings.format '{format_setting}' is not standard, using 'json'"
            )

        if not isinstance(config["output_settings"].get("verbose"), bool):
            errors.append("output_settings.verbose must be a boolean")

    # Return validation results
    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "validated_config": config if len(errors) == 0 else default_config,
    }


def main():
    """Main entry point for the configuration validator."""

    # Read input from stdin or file argument
    if len(sys.argv) > 1:
        # Read from file specified as command line argument
        config_file = Path(sys.argv[1])
        try:
            with open(config_file, "r") as f:
                config_data = json.load(f)
        except Exception as e:
            print(
                json.dumps(
                    {
                        "valid": False,
                        "errors": [f"Failed to read configuration file: {str(e)}"],
                        "warnings": [],
                        "validated_config": {},
                    }
                )
            )
            sys.exit(1)
    else:
        # Read from stdin
        try:
            config_data = json.load(sys.stdin)
        except Exception as e:
            print(
                json.dumps(
                    {
                        "valid": False,
                        "errors": [f"Failed to read configuration: {str(e)}"],
                        "warnings": [],
                        "validated_config": {},
                    }
                )
            )
            sys.exit(1)

    # Validate the configuration
    result = validate_config(config_data)

    # Output results as JSON
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
