---
name: config-management
description: Manage tool configurations and project-specific settings for code review processes
license: MIT
compatibility: opencode
metadata:
  audience: maintainers
  workflow: github
---
# Configuration Management Skill

This skill defines how configuration is handled across the code review process.

## Purpose
Establishes standardized approaches for managing tool configurations and project-specific settings to ensure consistent, reproducible analysis results.

## Rules and Standards
- Load default configurations from repository defaults with clear fallbacks
- Allow project-specific overrides through environment variables with proper validation  
- Validate all configuration parameters before use with comprehensive error handling
- Support hierarchical configuration (global → project → local) with explicit precedence rules
- Document all configurable parameters with clear descriptions, types, and acceptable values

## Configuration Elements
- Tool execution timeouts and limits (with minimum/maximum bounds)
- Severity thresholds for different issue types (error, warning, info) with rationale
- Analysis scope parameters (include/exclude patterns) with glob pattern validation
- Output formatting preferences including file formats and verbosity levels
- Resource allocation settings for parallel processing

## Integration Points
- Used by config-manager-agent for parameter handling  
- Connected to all analyzer agents that require settings
- Provides validated configurations to main-agent through structured JSON interface
- Supports configuration reloading during long-running processes

## Validation Requirements
- Check all numeric values are within acceptable ranges with descriptive error messages
- Validate boolean flags have correct values and default to sensible defaults
- Ensure file paths exist, are accessible, and resolve within repository boundaries
- Verify tool parameters conform to expected formats with comprehensive type checking
- Validate that configuration combinations are logically consistent

## Configuration Schema
```json
{
  "tool_settings": {
    "ruff": {
      "timeout_seconds": 30,
      "max_issues_per_file": 100
    },
    "mypy": {
      "timeout_seconds": 60,
      "strict_mode": true
    }
  },
  "analysis_scope": {
    "include_patterns": ["src/**/*.py"],
    "exclude_patterns": ["tests/**", "*/_test.py"]
  },
  "output_settings": {
    "format": "json",
    "verbose": false
  }
}
```