#!/usr/bin/env python3
"""
Ruff runner script for PatchSorter v2 code review process.

This script executes ruff linting with specific project configurations and
returns structured results for the code review system.
"""

import subprocess
import json
import sys
import os
from pathlib import Path
from typing import List, Dict, Any


def run_ruff_analysis(
    files: List[str], config: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Run ruff analysis on specified files with project-specific configuration.

    Args:
        files: List of file paths to analyze
        config: Configuration dictionary for ruff settings

    Returns:
        Dictionary containing analysis results and statistics
    """

    # Default configuration if none provided
    if config is None:
        config = {
            "timeout_seconds": 30,
            "max_issues_per_file": 100,
            "line_length_limit": 88,
            "exclude_patterns": ["tests/**", "*/_test.py"],
        }

    try:
        # Prepare command - run ruff check with JSON output format
        cmd = [
            sys.executable,
            "-m",
            "ruff",
            "check",
            "--output-format",
            "json",
            "--line-length",
            str(config.get("line_length_limit", 88)),
            "--extend-ignore",
            "E501",  # Allow long lines in certain cases for readability
        ]

        # Add all files to analyze
        for file_path in files:
            if Path(file_path).exists():
                cmd.append(str(file_path))

        # Run the analysis with timeout
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=config.get("timeout_seconds", 30),
        )

        # Parse JSON output if available
        issues = []
        total_issues = 0

        if result.stdout.strip():
            try:
                raw_issues = json.loads(result.stdout.strip())
                issues = raw_issues
                total_issues = len(issues) if isinstance(issues, list) else 0
            except json.JSONDecodeError as e:
                # Fallback - treat stdout as plain text errors
                lines = result.stdout.strip().split("\n") if result.stdout else []
                for line in lines[:10]:  # Limit to first 10 lines for safety
                    issues.append(
                        {"message": f"Ruff issue: {line}", "severity": "error"}
                    )

        # Get summary statistics
        by_severity = {"error": 0, "warning": 0}

        # Count severity levels (if available in the JSON structure)
        for issue in issues:
            if isinstance(issue, dict):
                severity = issue.get("severity", "").lower()
                if severity == "error":
                    by_severity["error"] += 1
                elif severity == "warning":
                    by_severity["warning"] += 1

        return {
            "success": True,
            "issues": issues,
            "summary": {
                "total_issues": total_issues,
                "by_severity": by_severity,
                "files_analyzed": len(files),
            },
            "errors": [],
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "issues": [],
            "summary": {
                "total_issues": 0,
                "by_severity": {"error": 0, "warning": 0},
                "files_analyzed": len(files),
            },
            "errors": [
                "Ruff analysis timed out after {} seconds".format(
                    config.get("timeout_seconds", 30)
                )
            ],
        }
    except Exception as e:
        return {
            "success": False,
            "issues": [],
            "summary": {
                "total_issues": 0,
                "by_severity": {"error": 0, "warning": 0},
                "files_analyzed": len(files),
            },
            "errors": [f"Ruff analysis failed: {str(e)}"],
        }


def main():
    """Main entry point for the ruff runner."""

    # Read input from stdin
    try:
        input_data = json.load(sys.stdin)
    except Exception as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "issues": [],
                    "summary": {
                        "total_issues": 0,
                        "by_severity": {"error": 0, "warning": 0},
                        "files_analyzed": 0,
                    },
                    "errors": [f"Failed to read input: {str(e)}"],
                }
            )
        )
        sys.exit(1)

    # Extract files and config from input
    files = input_data.get("files", [])
    config = input_data.get("config", None)

    # Run the analysis
    result = run_ruff_analysis(files, config)

    # Output results as JSON
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
