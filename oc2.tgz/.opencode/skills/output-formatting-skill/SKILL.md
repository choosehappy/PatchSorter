---
name: output-formatting
description: Define report generation and output formatting standards for code review processes
license: MIT
compatibility: opencode
metadata:
  audience: maintainers
  workflow: github
---
# Output Formatting Skill

This skill defines report generation and output formatting standards for the code review process.

## Purpose
Establishes standardized approaches for presenting analysis results to users with consistent, actionable formats across all tools.

## Rules and Standards
- Define JSON schema for all result outputs with comprehensive documentation  
- Specify logging format conventions that are both machine-readable and human-friendly
- Establish audit trail requirements for traceability of review processes
- Set human-readable report formats that prioritize actionable insights over raw data
- Ensure consistent formatting across different output types (terminal, file, web)

## Integration Points
- Used by report-generator-agent for output formatting
- Connected to logger-agent for log message standards  
- Provides structure definitions to validation processes

## Parameters
- `output_format` (string): Format of final results ('json', 'markdown', 'html') with clear use cases
- `log_level` (string): Default logging level for operations ('debug', 'info', 'warning', 'error')
- `timestamp_format` (string): Date/time format for logs and reports consistent with ISO 8601
- `max_output_size` (integer): Maximum size of output files in bytes to prevent memory issues
- `report_sections` (array): Ordered list of report sections to include in all outputs

## Output Structure Example
```json
{
  "review_metadata": {
    "commit_reference": "abc1234",
    "timestamp": "2026-04-07T10:30:00Z",
    "tool_versions": {
      "ruff": "0.1.0",
      "mypy": "1.0.0",
      "pytest": "7.0.0"
    },
    "review_environment": {
      "platform": "linux",
      "python_version": "3.8.10"
    }
  },
  "analysis_results": {
    "ruff_analysis": {
      "issues": [
        {
          "file_path": "src/main.py",
          "line_number": 42,
          "rule_code": "E501", 
          "message": "Line too long (89 > 88 characters)",
          "severity": "warning"
        }
      ],
      "summary": {
        "total_issues": 15,
        "by_severity": {
          "error": 2,
          "warning": 13
        }
      }
    },
    "mypy_analysis": {
      "issues": [
        {
          "file_path": "src/utils.py",
          "line_number": 27,
          "message": "Incompatible types in assignment (expression has type \"str\", variable has type \"int\")",
          "severity": "error"
        }
      ],
      "summary": {
        "total_errors": 1,
        "by_severity": {
          "error": 1
        }
      }
    },
    "test_results": {
      "passed": 42,
      "failed": 0,
      "skipped": 3,
      "duration_seconds": 15.2
    },
    "coverage_results": {
      "overall_coverage": 87.5,
      "by_file": [
        {
          "file_path": "src/main.py",
          "coverage_percent": 92.0
        }
      ],
      "summary": {
        "minimum_threshold_met": true,
        "coverage_target": 80.0
      }
    }
  },
  "summary_metrics": {
    "total_files_analyzed": 42,
    "total_issues_found": 16,
    "review_status": "pass",
    "recommendations": [
      "Fix the type error in src/utils.py",
      "Address the line length warning in src/main.py"
    ]
  }
}
```

## Report Sections Guidelines
- **Metadata**: Commit information, timestamps, tool versions for reproducibility 
- **Detailed Results**: Per-tool analysis with file paths, line numbers, and specific issues
- **Summary Metrics**: High-level overview with actionable metrics
- **Recommendations**: Concrete next steps based on findings
- **Context Information**: Additional details that help understand the results

## Output Standards
- All timestamps must be in ISO 8601 format for consistency 
- Error messages should include specific file locations and line numbers
- Severity levels should be consistently defined across all tools (error, warning, info)
- Reports should be structured to allow easy parsing by automated systems while remaining readable by humans

## Format-Specific Considerations
- **JSON**: Machine-readable with complete data structure for integration 
- **Markdown**: Human-friendly with clear formatting and linking capabilities
- **HTML**: Rich presentation with navigation aids and visual elements where appropriate