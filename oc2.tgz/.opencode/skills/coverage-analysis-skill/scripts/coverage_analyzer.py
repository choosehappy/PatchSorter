#!/usr/bin/env python3
"""
Coverage analyzer script for PatchSorter v2 code review process.

This script executes coverage analysis with specific project configurations and
returns structured results for the code review system.
"""

import subprocess
import json
import sys
from pathlib import Path
from typing import List, Dict, Any


def run_coverage_analysis(
    source_paths: List[str], config: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Run coverage analysis on specified source paths with project-specific configuration.

    Args:
        source_paths: List of source file/directory paths to analyze
        config: Configuration dictionary for coverage settings

    Returns:
        Dictionary containing coverage results and statistics
    """

    # Default configuration if none provided
    if config is None:
        config = {
            "minimum_coverage_percent": 80.0,
            "include_test_files": False,
            "coverage_format": "json",
            "fail_under_threshold": 80.0,
            "omit_patterns": ["*/tests/*", "*/venv/*", "*/.venv/*"],
        }

    try:
        # Prepare command - run coverage with specific settings
        cmd = [
            sys.executable,
            "-m",
            "coverage",
            "run",
            "--source=" + ",".join(source_paths),
            "--omit="
            + ",".join(
                config.get("omit_patterns", ["*/tests/*", "*/venv/*", "*/.venv/*"])
            ),
        ]

        # Add test paths if available
        cmd.append("--")

        # Run coverage with timeout (using a reasonable default)
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,  # Default 60s timeout
        )

        # Generate report in specified format
        if config.get("coverage_format", "json") == "html":
            coverage_cmd = [
                sys.executable,
                "-m",
                "coverage",
                "html",
                "--directory=coverage_html_report",
            ]
            subprocess.run(coverage_cmd, capture_output=True)

        # Generate JSON report
        json_cmd = [sys.executable, "-m", "coverage", "json"]
        json_result = subprocess.run(json_cmd, capture_output=True, text=True)

        coverage_data = {}
        if json_result.stdout:
            try:
                coverage_data = json.loads(json_result.stdout)
            except Exception:
                pass  # No valid JSON data

        # Get overall coverage percentage
        total_coverage = 0.0
        if "totals" in coverage_data and "percent_covered" in coverage_data["totals"]:
            total_coverage = float(coverage_data["totals"]["percent_covered"])

        return {
            "success": True,
            "coverage_data": coverage_data,
            "summary": {
                "total_coverage_percent": total_coverage,
                "minimum_required_percent": config.get(
                    "minimum_coverage_percent", 80.0
                ),
                "sources_analyzed": len(source_paths),
                "format_used": config.get("coverage_format", "json"),
            },
            "errors": [],
            "report_path": "coverage.json" if json_result.stdout else "",
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "coverage_data": {},
            "summary": {
                "total_coverage_percent": 0.0,
                "minimum_required_percent": config.get(
                    "minimum_coverage_percent", 80.0
                ),
                "sources_analyzed": len(source_paths),
                "format_used": config.get("coverage_format", "json"),
            },
            "errors": ["Coverage analysis timed out after 60 seconds"],
            "report_path": "",
        }
    except Exception as e:
        return {
            "success": False,
            "coverage_data": {},
            "summary": {
                "total_coverage_percent": 0.0,
                "minimum_required_percent": config.get(
                    "minimum_coverage_percent", 80.0
                ),
                "sources_analyzed": len(source_paths),
                "format_used": config.get("coverage_format", "json"),
            },
            "errors": [f"Coverage analysis failed: {str(e)}"],
            "report_path": "",
        }


def main():
    """Main entry point for the coverage analyzer."""

    # Read input from stdin
    try:
        input_data = json.load(sys.stdin)
    except Exception as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "coverage_data": {},
                    "summary": {
                        "total_coverage_percent": 0.0,
                        "minimum_required_percent": 80.0,
                        "sources_analyzed": 0,
                        "format_used": "json",
                    },
                    "errors": [f"Failed to read input: {str(e)}"],
                    "report_path": "",
                }
            )
        )
        sys.exit(1)

    # Extract source paths and config from input
    source_paths = input_data.get("source_paths", [])
    config = input_data.get("config", None)

    # Run the coverage analysis
    result = run_coverage_analysis(source_paths, config)

    # Output results as JSON
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
