---
name: coverage-analysis
description: Define code coverage analysis requirements and standards for PatchSorter v2
license: MIT
compatibility: opencode
metadata:
  audience: maintainers
  workflow: github
---
# Coverage Analysis Skill

This skill defines code coverage analysis rules and standards for PatchSorter v2.

## Purpose
Establishes the specific coverage analysis requirements that should be applied to code review process with clear thresholds and reporting standards.

## Rules and Standards
- Define minimum coverage thresholds for different file types with documented rationale  
- Specify which files should be included/excluded from coverage analysis with clear criteria
- Set reporting formats for coverage data with appropriate verbosity levels
- Establish how coverage results are interpreted in context of code quality metrics
- Require coverage reports to be generated consistently across all environments

## Integration Points
- Used by coverage-analyzer-agent for coverage measurement  
- Connected to main-agent for result interpretation
- Provides metrics to validation processes
- Integrated with test execution to ensure comprehensive quality assessment

## Parameters
- `minimum_coverage_percent` (float): Minimum overall coverage percentage required with clear pass/fail criteria
- `file_coverage_thresholds` (object): Thresholds by file type with specific targets for different code categories  
- `include_test_files` (boolean): Whether to include test files in analysis with documented rationale
- `coverage_format` (string): Output format for coverage reports ('json', 'xml', 'html', 'txt')
- `fail_under_threshold` (float): Threshold at which coverage failures are reported 
- `omit_patterns` (array): File patterns to exclude from coverage analysis

## Coverage Configuration Examples
```ini
# Standard coverage configuration with project-specific thresholds and exclusions
omit = [
    "*/tests/*",
    "*/venv/*", 
    "*/.venv/*",
    "*/migrations/*"
]
fail_under = 80
show_missing = true
skip_covered = false

[run]
source = ["src"]
omit = [
    "*/tests/*",
    "*/venv/*", 
    "*/.venv/*"
]

[report]
exclude_lines =
    pragma: no cover
    def __repr__
    raise AssertionError
    raise NotImplementedError
```

## Coverage Threshold Guidelines
- Overall project minimum: 80% coverage (target 90%)
- Critical modules: 95%+ coverage required  
- Test files: Excluded from coverage analysis by default
- Documentation and examples: May be excluded with justification

## Reporting Requirements
- Generate detailed HTML reports for manual review
- Provide machine-readable JSON output for CI integration
- Include line-by-line coverage information for identified gaps
- Show coverage trends over time to track improvement progress

## Performance Considerations
- Configure appropriate timeout values for large codebases
- Set reasonable resource limits to prevent excessive memory usage  
- Enable parallel processing where possible for faster analysis
- Implement caching mechanisms to avoid redundant coverage calculations

## Script Integration
This skill's functionality is implemented by the script at `.opencode/skills/coverage-analysis-skill/scripts/coverage_runner.py` which provides the actual execution logic for running coverage analysis.