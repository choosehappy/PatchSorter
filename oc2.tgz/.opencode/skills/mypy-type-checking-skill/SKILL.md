---
name: mypy-type-checking
description: Define mypy-specific type checking rules and standards for PatchSorter v2
license: MIT
compatibility: opencode
metadata:
  audience: maintainers
  workflow: github
---
# Mypy Type Checking Skill

This skill defines mypy-specific type checking rules and standards for PatchSorter v2.

## Purpose
Establishes the specific mypy type checking requirements that should be applied to code review process with clear documentation of trade-offs and exceptions.

## Rules and Standards
- Enforce strict type checking with project-specific allowances  
- Define severity levels (error, warning) with clear definitions:
  - Error: Type mismatches that will cause runtime failures or logical errors 
  - Warning: Potential issues in type annotations that don't break functionality but reduce code quality
- Specify which mypy checks are enabled/disabled based on project requirements and maintainability considerations
- Set threshold values for type errors per file with clear escalation procedures
- Ensure consistent use of type hints throughout the codebase

## Integration Points
- Used by mypy-analyzer-agent for type validation  
- Connected to main-agent for result interpretation
- Provides checking rules to validation processes
- Integrated with ruff linting for comprehensive code quality assessment

## Parameters
- `strict_mode` (boolean): Enable strict type checking mode with comprehensive error detection
- `enable_plugins` (array): List of mypy plugins to enable with specific documentation on each plugin's purpose
- `disable_error_codes` (array): Error codes to ignore with detailed rationale for each exclusion  
- `max_errors_per_file` (integer): Maximum allowed errors per file before triggering warning/error status
- `python_version` (string): Target Python version for type checking compatibility
- `ignore_missing_imports` (boolean): Whether to ignore missing imports during analysis

## Mypy Configuration Examples
```toml
# Strict type checking with project-specific allowances and performance considerations
strict = true
warn_return_any = true
warn_unused_configs = true
disallow_untyped_defs = true
disallow_incomplete_defs = true
check_untyped_defs = true
disallow_untyped_decorators = true

# Project-specific configurations  
python_version = "3.8"
ignore_missing_imports = false
show_error_codes = true
```

## Type Checking Guidelines
- Require type annotations for all function parameters and return values in new code
- Maintain existing type hints in legacy code during refactoring 
- Use Union types appropriately to express multiple valid input types
- Apply proper typing for complex data structures like lists, dictionaries, and custom classes
- Document type assumptions with comments where necessary

## Performance Considerations
- Configure appropriate timeout values to prevent hanging on large modules
- Set reasonable error thresholds to avoid overwhelming developers with too many issues  
- Enable incremental checking for faster development cycles
- Use `--no-error-summary` in CI environments to reduce output verbosity when not needed

## Script Integration
This skill's functionality is implemented by the script at `.opencode/skills/mypy-type-checking-skill/scripts/mypy_runner.py` which provides the actual execution logic for running mypy analysis.