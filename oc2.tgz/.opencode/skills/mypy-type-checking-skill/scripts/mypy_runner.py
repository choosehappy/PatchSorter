#!/usr/bin/env python3
"""
Mypy runner script for PatchSorter v2 code review process.

This script executes mypy type checking with specific project configurations and
returns structured results for the code review system.
"""

import subprocess
import json
import sys
from pathlib import Path
from typing import List, Dict, Any


def run_mypy_analysis(
    files: List[str], config: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Run mypy analysis on specified files with project-specific configuration.

    Args:
        files: List of file paths to analyze
        config: Configuration dictionary for mypy settings

    Returns:
        Dictionary containing analysis results and statistics
    """

    # Default configuration if none provided
    if config is None:
        config = {"timeout_seconds": 60, "strict_mode": True, "python_version": "3.8"}

    try:
        # Prepare command - run mypy with JSON output format
        cmd = [
            sys.executable,
            "-m",
            "mypy",
            "--show-error-codes",
            "--json",
            "--python-version",
            config.get("python_version", "3.8"),
        ]

        # Add strict mode if enabled
        if config.get("strict_mode", True):
            cmd.append("--strict")

        # Add all files to analyze
        for file_path in files:
            if Path(file_path).exists():
                cmd.append(str(file_path))

        # Run the analysis with timeout
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=config.get("timeout_seconds", 60),
        )

        # Parse JSON output if available
        issues = []
        total_errors = 0

        if result.stdout.strip():
            try:
                raw_issues = json.loads(result.stdout.strip())
                issues = raw_issues.get("errors", [])
                total_errors = len(issues)
            except json.JSONDecodeError as e:
                # Fallback - treat stdout as plain text errors
                lines = result.stdout.strip().split("\n") if result.stdout else []
                for line in lines[:10]:  # Limit to first 10 lines for safety
                    issues.append(
                        {"message": f"Mypy error: {line}", "severity": "error"}
                    )

        # Get summary statistics
        by_severity = {"error": total_errors, "warning": 0}

        return {
            "success": True,
            "issues": issues,
            "summary": {
                "total_errors": total_errors,
                "by_severity": by_severity,
                "files_analyzed": len(files),
            },
            "errors": [],
        }

    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "issues": [],
            "summary": {
                "total_errors": 0,
                "by_severity": {"error": 0, "warning": 0},
                "files_analyzed": len(files),
            },
            "errors": [
                "Mypy analysis timed out after {} seconds".format(
                    config.get("timeout_seconds", 60)
                )
            ],
        }
    except Exception as e:
        return {
            "success": False,
            "issues": [],
            "summary": {
                "total_errors": 0,
                "by_severity": {"error": 0, "warning": 0},
                "files_analyzed": len(files),
            },
            "errors": [f"Mypy analysis failed: {str(e)}"],
        }


def main():
    """Main entry point for the mypy runner."""

    # Read input from stdin
    try:
        input_data = json.load(sys.stdin)
    except Exception as e:
        print(
            json.dumps(
                {
                    "success": False,
                    "issues": [],
                    "summary": {
                        "total_errors": 0,
                        "by_severity": {"error": 0, "warning": 0},
                        "files_analyzed": 0,
                    },
                    "errors": [f"Failed to read input: {str(e)}"],
                }
            )
        )
        sys.exit(1)

    # Extract files and config from input
    files = input_data.get("files", [])
    config = input_data.get("config", None)

    # Run the analysis
    result = run_mypy_analysis(files, config)

    # Output results as JSON
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
