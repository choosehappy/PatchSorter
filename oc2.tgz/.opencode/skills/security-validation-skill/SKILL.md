---
name: security-validation
description: Define security validation rules and sandboxing approaches for code review processes
license: MIT
compatibility: opencode
metadata:
  audience: maintainers
  workflow: github
---
# Security Validation Skill

This skill defines security validation rules and sandboxing approaches for the code review process.

## Purpose
Establishes security measures to protect against malicious inputs and ensure safe execution of analysis tools in potentially untrusted environments.

## Rules and Standards
- Validate all file paths are within repository boundaries with comprehensive path traversal prevention  
- Sanitize input data to prevent injection attacks through all entry points
- Implement sandboxing for tool execution when possible with clear isolation guarantees
- Define acceptable resource usage limits (CPU, memory, time) to prevent DoS attacks
- Establish secure handling of sensitive information throughout the review process

## Integration Points
- Used by validator-agent for security checks
- Connected to logger-agent for audit trails  
- Provides validation rules to error-handler-agent
- Integrated with all agent processes that handle external inputs or file operations

## Validation Requirements
- All file paths must resolve within repository directory with comprehensive path sanitization
- Commit references must be valid git objects with proper verification steps
- Tool parameters must not contain malicious content through input filtering and validation
- Execution environments must have appropriate permissions and isolation measures
- Data handling must comply with privacy requirements for any sensitive information

## Security Measures
- **Path traversal prevention**: All file paths are validated against repository root to prevent directory traversal attacks  
- **Input sanitization and escaping**: All external inputs are sanitized before processing to prevent injection vulnerabilities
- **Resource limit enforcement**: CPU, memory, and execution time limits enforced on all tools to prevent resource exhaustion
- **Isolated execution environment**: Tools execute in restricted environments with minimal permissions when possible

## Security Implementation Guidelines
- Validate all inputs at the entry point of each agent process
- Implement timeouts for all external tool executions 
- Use secure temporary file handling with automatic cleanup
- Avoid executing untrusted code or shell commands directly
- Log security-relevant events for audit purposes
- Regularly update dependencies to address known vulnerabilities

## Threat Modeling Considerations
- **Malicious inputs**: Attackers may attempt to inject malicious paths, command-line arguments, or configuration values
- **Resource exhaustion**: Adversaries might try to consume excessive system resources through large files or loops  
- **Directory traversal**: Attempted access to files outside the repository boundaries
- **Code injection**: Potential for code execution through improperly sanitized inputs

## Security Testing Requirements
- Validate that all file paths are properly sandboxed within repository boundaries 
- Test that resource limits prevent denial-of-service attacks
- Verify that input sanitization prevents command injection and other attack vectors
- Confirm that security measures don't significantly impact performance or usability